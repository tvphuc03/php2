<?php
include_once("app/init.php");
?>