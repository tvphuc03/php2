<div class="container">
    <div class="container mt-3 text-center">
      <h2>GIỎ HÀNG</h2>
      <table class="table table-bordered">
        <thead>
          
        </thead>
        <tbody>
          <?php
          viewcart(1);
          ?>
        </tbody>
      </table>
      <a href="index.php?act=bill"><button type="submit" name="Them" class="btn btn-primary mb-3">Đặt Hàng</button></a>
      <a href="index.php?act=deletecart"><button type="submit" name="Them" class="btn btn-primary mb-3">Xóa Tất Cả</button></a>
    </div>
  </div>