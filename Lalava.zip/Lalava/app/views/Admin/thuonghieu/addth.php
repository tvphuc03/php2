<h2>Thêm Thương Hiệu</h2>
<form action="" method="post">
    <input type="text" name="txtname" >
    <button class="btn-danger btn">Lưu</button>
    <a href="<?php echo base_url; ?>thuonghieu" class="btnds btn-danger btn">Danh Sách</a>
</form>
