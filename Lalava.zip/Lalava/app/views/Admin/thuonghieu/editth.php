<h2>Sửa danh mục</h2>
<form action="" method="post">
    <input type="text" name="txtname" value="<?php echo $data[0]["TenTH"] ?>">
    <button>Sửa</button><br><br>
    <br>
    <br>
    <br>
    <br>
    <br>
</form>