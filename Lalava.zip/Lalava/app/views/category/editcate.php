<h2>Sửa danh mục</h2>
<form action="" method="post">
    <input type="text" name="txtname" value="<?php echo $data[0]["name"] ?>">
    <button>Sửa</button>
</form>