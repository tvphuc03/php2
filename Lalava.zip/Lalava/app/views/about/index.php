<p style="font-size:100px"> Trang Giới thiệu </p>
<?php
echo $data['content'];
?>