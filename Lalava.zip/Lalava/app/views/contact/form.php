<form action="">
    Họ Và Tên 
    <input type="text" name="" id=""><br>
    Email 
    <input type="text" name="" id=""><br>
    Phone 
    <input type="text" name="" id=""><br>
    Nội Dung <br>
    <textarea name="" id="" cols="30" rows="10"></textarea><br>
    <button>Submit</button>
</form>